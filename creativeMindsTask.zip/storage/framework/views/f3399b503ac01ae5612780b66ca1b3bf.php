
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal3d4e3f5369e04c2cf115b9f764b9480e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d4e3f5369e04c2cf115b9f764b9480e = $attributes; } ?>
<?php $component = App\View\Components\Nav::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Nav::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d4e3f5369e04c2cf115b9f764b9480e)): ?>
<?php $attributes = $__attributesOriginal3d4e3f5369e04c2cf115b9f764b9480e; ?>
<?php unset($__attributesOriginal3d4e3f5369e04c2cf115b9f764b9480e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d4e3f5369e04c2cf115b9f764b9480e)): ?>
<?php $component = $__componentOriginal3d4e3f5369e04c2cf115b9f764b9480e; ?>
<?php unset($__componentOriginal3d4e3f5369e04c2cf115b9f764b9480e); ?>
<?php endif; ?>
    <div class="container">
        <a href="<?php echo e(route('users.create')); ?>?role=<?php echo e(request()->role); ?>" class="btn btn-primary">Create <?php echo e(ucfirst(request()->role)); ?></a>
        <table class="table table-stripedm-auto text-center">
            <tr>
                <th>ID</th>
                <th>USERNAME</th>
                <th>PHONE</th>
                <th>ROLE</th>
                <th>image</th>
                <th>CONTROLLERS</th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><a class="text-decoration-none" href="<?php echo e(route('users.show', $user->id)); ?>"><?php echo e($user->username); ?></a>
                    </td>
                    <td><?php echo e($user->mobile); ?></td>
                    <td><?php echo e($user->role); ?></td>
                    <td><img class="rounded" src="<?php echo e($user->image); ?>" alt="" width="50"></td>
                    <td class="d-flex gap-2 justify-content-center">
                        <a href="<?php echo e(route('users.edit', $user->id)); ?>?role=<?php echo e(request()->role); ?>"
                            class="btn btn-primary">Edit</a>
                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>?role=<?php echo e(request()->role); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger">DELETE</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\إدارة مرور الدقهلية\Desktop\auth\resources\views/users/users.blade.php ENDPATH**/ ?>