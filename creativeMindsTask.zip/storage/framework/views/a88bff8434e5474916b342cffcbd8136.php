
<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal3d4e3f5369e04c2cf115b9f764b9480e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d4e3f5369e04c2cf115b9f764b9480e = $attributes; } ?>
<?php $component = App\View\Components\Nav::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Nav::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d4e3f5369e04c2cf115b9f764b9480e)): ?>
<?php $attributes = $__attributesOriginal3d4e3f5369e04c2cf115b9f764b9480e; ?>
<?php unset($__attributesOriginal3d4e3f5369e04c2cf115b9f764b9480e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d4e3f5369e04c2cf115b9f764b9480e)): ?>
<?php $component = $__componentOriginal3d4e3f5369e04c2cf115b9f764b9480e; ?>
<?php unset($__componentOriginal3d4e3f5369e04c2cf115b9f764b9480e); ?>
<?php endif; ?>
    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="post" class="custom-form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <h3 class="text-center p-2">Edit User</h3>
        <div class="row mb-3">
            <label for="username" class="col-sm-2 col-form-label">Username</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="username" id="username" required
                    value="<?php echo e($user->username); ?>">
                <?php if($errors->has('username')): ?>
                    <p class="text-danger"><?php echo e($errors->first('username')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-3">
            <label for="mobile" class="col-sm-2 col-form-label">Phone</label>
            <div class="col-sm-10">
                <input type="tel" class="form-control" name="mobile" id="mobile" required
                    value="<?php echo e($user->mobile); ?>">
                <?php if($errors->has('mobile')): ?>
                    <p class="text-danger"><?php echo e($errors->first('mobile')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-3">
            <label for="lng" class="col-sm-2 col-form-label">Location</label>
            <div class="col-5">
                <input type="number" class="form-control" name="lng" id="lng" placeholder="lng"
                    value="<?php echo e($user->lng); ?>">
                <?php if($errors->has('lng')): ?>
                    <p class="text-danger"><?php echo e($errors->first('lng')); ?></p>
                <?php endif; ?>
            </div>
            <div class="col-5">
                <input type="number" class="form-control" name="lat" id="lat" placeholder="lat"
                    value="<?php echo e($user->lat); ?>">
                <?php if($errors->has('lat')): ?>
                    <p class="text-danger"><?php echo e($errors->first('lat')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-2" for="image" class="form-label">Image</label>
            <div class="col-10">
                <input class="form-control" type="file" id="image" name="image">
                <?php if($errors->has('image')): ?>
                    <p class="text-danger"><?php echo e($errors->first('image')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-3">
            <label for="roles" class="col-sm-2 col-form-label">Roles</label>
            <div class="col-sm-10">
                <select class="form-control" name="role" id="roles" required>
                    <option value="admin" <?php if($user->role == 'admin'): ?> selected <?php endif; ?>>Admin</option>
                    <option value="user" <?php if($user->role == 'user'): ?> selected <?php endif; ?>>User</option>
                    <option value="delivery" <?php if($user->role == 'delivery'): ?> selected <?php endif; ?>>Delivery</option>
                </select>
                <?php if($errors->has('role')): ?>
                    <p class="text-danger"><?php echo e($errors->first('role')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-3">
            <label for="password" class="col-sm-2 col-form-label">Password</label>
            <div class="col-sm-10">
                <input type="password" class="form-control" name="password" id="password">
                <?php if($errors->has('password')): ?>
                    <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <button id="submitBtn" type="submit" class="btn btn-primary">Save</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\إدارة مرور الدقهلية\Desktop\auth\resources\views/users/edit.blade.php ENDPATH**/ ?>